package com.Modul4.marvel.universe.ui.Character

import com.Modul4.marvel.universe.domain.model.CharacterModel

data class CharacterState(
    val isLoading : Boolean = false,
    val characterDetail : List<CharacterModel> = emptyList(),
    val error : String = ""
)