package com.Modul4.marvel.universe.ui.CharactersList

import com.Modul4.marvel.universe.domain.model.CharacterModel

data class MarvelListState(
    val isLoading : Boolean = false,
    val charactersList : List<CharacterModel> = emptyList(),
    val error : String = ""
)