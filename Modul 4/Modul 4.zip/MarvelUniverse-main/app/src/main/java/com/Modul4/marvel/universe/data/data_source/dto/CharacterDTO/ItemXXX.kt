package com.Modul4.marvel.universe.data.data_source.dto.CharacterDTO

data class ItemXXX(
    val name: String,
    val resourceURI: String,
    val type: String
)