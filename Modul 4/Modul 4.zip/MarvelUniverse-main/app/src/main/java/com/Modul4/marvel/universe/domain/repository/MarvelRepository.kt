package com.Modul4.marvel.universe.domain.repository

import com.Modul4.marvel.universe.data.data_source.dto.CharacterDTO.CharacterDTO
import com.Modul4.marvel.universe.data.data_source.dto.CharactersDTO.CharactersDTO

interface MarvelRepository {

    suspend fun getAllCharacters(offset:Int):CharactersDTO
    suspend fun getAllSearchedCharacters(search:String):CharactersDTO
    suspend fun getCharacterById(id:String):CharacterDTO
}