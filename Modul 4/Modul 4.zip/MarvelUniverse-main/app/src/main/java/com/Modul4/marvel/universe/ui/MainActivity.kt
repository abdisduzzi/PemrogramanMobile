package com.Modul4.marvel.universe.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.Modul4.marvel.universe.databinding.ActivityMainBinding
import com.Modul4.marvel.universe.domain.model.CharacterModel
import com.Modul4.marvel.universe.ui.CharactersList.CharactersViewModel
import com.Modul4.marvel.universe.utils.CharacterListAdapter
import com.Modul4.marvel.universe.utils.Constants
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : AppCompatActivity(), androidx.appcompat.widget.SearchView.OnQueryTextListener {

    private lateinit var searchQuery: String
    private var repeatCount = 3
    private var currentPage = 0
    private lateinit var binding: ActivityMainBinding
    private lateinit var characterRecyclerView: RecyclerView
    private lateinit var characterAdapter: CharacterListAdapter
    private lateinit var gridLayoutManager: GridLayoutManager
    private val characterViewModel: CharactersViewModel by viewModels()
    private var characterList = arrayListOf<CharacterModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        characterRecyclerView = binding.characterRecyclerView
        gridLayoutManager = GridLayoutManager(this, 2)
        setupRecyclerView()
        characterRecyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (gridLayoutManager.findLastVisibleItemPosition() == gridLayoutManager.itemCount - 1) {
                    currentPage += 20
                    characterViewModel.getAllCharactersData(currentPage)
                    fetchAPI()
                }
            }
        })
        Log.d("tag", Constants.timeStamp)
    }

    private fun fetchAPI() {
        CoroutineScope(Dispatchers.Main).launch {
            repeat(repeatCount) {
                characterViewModel._marvelValue.collect { state ->
                    when {
                        state.isLoading -> {
                            binding.progressCircular.visibility = View.VISIBLE
                        }
                        state.error.isNotBlank() -> {
                            binding.progressCircular.visibility = View.GONE
                            repeatCount = 0
                            Toast.makeText(this@MainActivity, state.error, Toast.LENGTH_LONG).show()
                        }
                        state.charactersList.isNotEmpty() -> {
                            binding.progressCircular.visibility = View.GONE
                            repeatCount = 0
                            characterAdapter.setData(state.charactersList as ArrayList<CharacterModel>)
                        }
                    }
                    delay(1000)
                }
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun setupRecyclerView() {
        characterRecyclerView = binding.characterRecyclerView
        characterAdapter = CharacterListAdapter(this, ArrayList())
        characterRecyclerView.layoutManager = gridLayoutManager
        characterRecyclerView.adapter = characterAdapter
    }

    override fun onQueryTextSubmit(query: String?): Boolean {
        query?.let {
            searchQuery = it
            if (searchQuery.isNotEmpty()) {
                executeSearch()
            }
        }
        return true
    }

    override fun onQueryTextChange(query: String?): Boolean {
        query?.let {
            searchQuery = it
            if (searchQuery.isNotEmpty()) {
                executeSearch()
            }
        }
        return true
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun executeSearch() {
        characterViewModel.getSearchedCharacters(searchQuery)
        CoroutineScope(Dispatchers.Main).launch {
            characterViewModel._marvelValue.collect { state ->
                when {
                    state.isLoading -> {
                        binding.progressCircular.visibility = View.VISIBLE
                    }
                    state.error.isNotBlank() -> {
                        binding.progressCircular.visibility = View.GONE
                        Toast.makeText(this@MainActivity, state.error, Toast.LENGTH_LONG).show()
                    }
                    state.charactersList.isNotEmpty() -> {
                        binding.progressCircular.visibility = View.GONE
                        characterAdapter.setData(state.charactersList as ArrayList<CharacterModel>)
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        characterViewModel.getAllCharactersData(currentPage)
        fetchAPI()
    }
}