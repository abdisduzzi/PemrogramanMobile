package com.Modul4.marvel.universe.data.data_source.dto.CharactersDTO

data class Thumbnail(
    val extension: String,
    val path: String
)