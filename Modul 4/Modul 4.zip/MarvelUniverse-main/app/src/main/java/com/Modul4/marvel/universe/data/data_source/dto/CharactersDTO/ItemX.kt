package com.Modul4.marvel.universe.data.data_source.dto.CharactersDTO

data class ItemX(
    val name: String,
    val resourceURI: String
)