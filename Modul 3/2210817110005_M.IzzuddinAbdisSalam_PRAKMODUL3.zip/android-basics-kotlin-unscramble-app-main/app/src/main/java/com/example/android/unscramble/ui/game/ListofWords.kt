package com.example.android.unscramble.ui.game


const val MAX_NO_OF_WORDS = 10
const val SCORE_INCREASE = 20

val allWordsList: List<String> =
    listOf("api", "batu", "cuci", "dasi", "enak", "foto", "gigi"
        , "halo", "ibu", "jari", "kaki", "lari", "mata", "nasi",
        "obat", "paku", "quiz", "roti", "susu", "tali", "uang",
        "vase", "wajah", "x-ray", "yoga", "zoo", "atas", "baju",
        "cara", "dana", "esai", "garis", "hutan", "isi", "jalan",
        "kursi", "laba", "main", "nadi", "orang", "pagi", "rasa",
        "sapi", "tanah", "ular", "warna", "acar", "bola", "cinta",
        "dada", "emas", "fakta", "gula", "hotel", "ikan", "kuda",
        "lampu", "mobil", "naga", "otak", "pintu", "raya", "soto",
        "telur", "uang", "villa", "waktu", "yacht", "zoom", "alam",
        "buku", "cat", "dua", "empat", "film", "guru", "hari", "ide",
        "juta", "kopi", "lima", "musik", "nomor", "opi", "pohon",
        "quran", "rumah", "satu", "tiang", "udang", "virus", "wisata",
        "xerox", "yakin", "zaman")